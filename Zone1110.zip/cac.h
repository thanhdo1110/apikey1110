#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Concac : NSObject
@end

NS_ASSUME_NONNULL_END
