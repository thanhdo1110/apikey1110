#import "Zone1110.h"
#import "cac.h"
#import "encrypt.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
// Những dòng dưới đâu là ví dụ cách mà paid chạy
// còn để dễ hiểu hơn với dạng tap ngón mở menu thì tôi có để file PubgLoad.mm trong dự án này làm ví dụ rồi, chỉ cần import Zone1110.h rồi thêm
/*
+ (void)load {
    [super load];

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

    Zone1110 *api = [[Zone1110 alloc] init];

    extraInfo = [PubgLoad new];
        
    [api setToken:@"dothanh1110-Q54VgLMB06nIYEHUedzXwCZTAvWN7su2d897dca4147d75fb46ab993939fe343b"];
[api login];
    [api paid:^{
            [extraInfo initTapGes];
            [extraInfo initTapGes2];[extraInfo tapIconView];
            [extraInfo tapIconView2];
    }];
});
}

*/
///////////////////////////////////////////////////////////////////////////

/*
@interface Concac()
@end

@implementation Concac

static Concac *extraInfo;
*/
NSString * const __contact = NSSENCRYPT("Liên hệ"); // Nội dung nút liên hệ
NSString * const __Confirm = NSSENCRYPT("Xác nhận"); // Nội dung nút xác nhận
 //token package
UIButton* InvisibleMenuButton;
UIButton* VisibleMenuButton;
UITextField* hideRecordTextfield;
UIView* hideRecordView;
/*
+ (void)load {
    [super load];

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

    Zone1110 *api = [[Zone1110 alloc] init];

    extraInfo = [Concac new];
        
    [api setToken:@"dothanh1110-Q54VgLMB06nIYEHUedzXwCZTAvWN7su2d897dca4147d75fb46ab993939fe343b"];
[api login];
    [api paid:^{
[extraInfo initTapGes];
    }];
});
}

- (void)initTapGes {
    UIView* mainView = [UIApplication sharedApplication].windows[0].rootViewController.view;

    hideRecordTextfield = [[UITextField alloc] init];
    hideRecordView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height)];
    [hideRecordView setBackgroundColor:[UIColor clearColor]];
    [hideRecordView setUserInteractionEnabled:YES];
    hideRecordTextfield.secureTextEntry = YES;
    [hideRecordView addSubview:hideRecordTextfield];

    // Kiểm tra delegate của sublayer
    CALayer *layer = hideRecordTextfield.layer;
    if (layer.sublayers.count > 0 && [layer.sublayers.firstObject.delegate isKindOfClass:[UIView class]]) {
        hideRecordView = (UIView *)layer.sublayers.firstObject.delegate;
    } else {
        hideRecordView = nil; // Xử lý trường hợp delegate không phải UIView
    }

    [[UIApplication sharedApplication].keyWindow addSubview:hideRecordView];

    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"https://img.upanh.tv/2024/09/21/IMG_6465.png"]];
    UIImage *decodedImage = [UIImage imageWithData:imageData];

    // InvisibleMenuButton
    InvisibleMenuButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    InvisibleMenuButton.frame = CGRectMake(0, 0, 50, 50);
    InvisibleMenuButton.backgroundColor = [UIColor clearColor];
    [InvisibleMenuButton addTarget:self action:@selector(buttonDragged:withEvent:) forControlEvents:UIControlEventTouchDragInside];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showMenu:)];
    tapGestureRecognizer.numberOfTapsRequired = 1;
    [InvisibleMenuButton addGestureRecognizer:tapGestureRecognizer];
    [[UIApplication sharedApplication].windows[0].rootViewController.view addSubview:InvisibleMenuButton];

    // VisibleMenuButton
    VisibleMenuButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    VisibleMenuButton.frame = CGRectMake(0, 0, 50, 50);
    VisibleMenuButton.backgroundColor = [UIColor clearColor];
    VisibleMenuButton.layer.cornerRadius = VisibleMenuButton.frame.size.width * 0.5f;
    [VisibleMenuButton setBackgroundImage:decodedImage forState:UIControlStateNormal];
    [hideRecordView addSubview:VisibleMenuButton];
}

- (void)showMenu:(UITapGestureRecognizer *)tapGestureRecognizer {
    if (tapGestureRecognizer.state == UIGestureRecognizerStateEnded) {
        // Thao tác hiển thị menu khi nhấn vào
    }
}

- (void)buttonDragged:(UIButton *)button withEvent:(UIEvent *)event {
    UITouch *touch = [[event touchesForView:button] anyObject];

    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;

    button.center = CGPointMake(button.center.x + delta_x, button.center.y + delta_y);
    
    CGRect mainFrame = [UIApplication sharedApplication].windows[0].rootViewController.view.bounds;
    if (button.center.x < 0) button.center = CGPointMake(0, button.center.y);
    if (button.center.y < 0) button.center = CGPointMake(button.center.x, 0);
    if (button.center.y > mainFrame.size.height) button.center = CGPointMake(button.center.x, mainFrame.size.height);
    if (button.center.x > mainFrame.size.width) button.center = CGPointMake(mainFrame.size.width, button.center.y);
    
    VisibleMenuButton.center = button.center;
    VisibleMenuButton.frame = button.frame;
}



@end
*/