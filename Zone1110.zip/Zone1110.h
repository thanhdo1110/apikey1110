#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface Zone1110 : NSObject
NS_ASSUME_NONNULL_BEGIN
- (void)setToken:(NSString *)token;
- (void)paid:(void (^)(void))execute;
- (void)login;
- (NSString *)getKey;
- (NSString *)deviceType;
- (NSString *)iOSVersion;
- (NSString *)getUDID;
extern NSString * const __contact;
extern NSString * const __Confirm;
//extern NSString * const __kHashDefaultValue;
@end
NS_ASSUME_NONNULL_END